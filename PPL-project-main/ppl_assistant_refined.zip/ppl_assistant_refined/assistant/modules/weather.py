from __future__ import annotations

import json
from difflib import get_close_matches
from pathlib import Path

from assistant.config import RESPONSE_FILE, WEATHER_FILE
from assistant.models import Command
from assistant.modules.base import Module


def find_closest(city_name: str, cities: list[str]) -> str | None:
    matches = get_close_matches(city_name, cities, n=1, cutoff=0.6)
    return matches[0] if matches else None


class WeatherModule(Module):
    def __init__(self, command: Command, *, weather_file: Path = WEATHER_FILE, response_file: Path = RESPONSE_FILE):
        super().__init__(command)
        self.weather_file = weather_file
        self.response_file = response_file

    def respond(self) -> str:
        data = json.loads(self.weather_file.read_text(encoding='utf-8'))
        responses = json.loads(self.response_file.read_text(encoding='utf-8'))

        if not self.command.location:
            return responses['error_handler']['location_404'].format(location='')

        date = self.command.date or '15/12/2024'
        date_weather_info = data.get(date)
        if not date_weather_info:
            return responses['error_handler']['date_404']

        normalized_location = self.command.location.replace(' ', '').lower()
        weather_info = next(
            (
                item
                for item in date_weather_info
                if item['city']['findname'].replace(' ', '').lower() == normalized_location
            ),
            None,
        )

        if weather_info is None:
            city_findnames = [item['city']['findname'].replace(' ', '').lower() for item in date_weather_info]
            closest_city = find_closest(normalized_location, city_findnames)
            if closest_city:
                match = next(item for item in date_weather_info if item['city']['findname'].replace(' ', '').lower() == closest_city)
                return responses['error_handler']['closest_match'].format(closest_city_name=match['city']['name'])
            return responses['error_handler']['location_404'].format(location=self.command.location)

        city = weather_info['city']['name']
        description = weather_info['weather'][0]['description']
        temperature = weather_info['main']['temp'] - 273.15
        humidity = weather_info['main']['humidity']
        wind_speed = weather_info['wind']['speed']

        if self.command.verb == 'show':
            return responses['weather']['show'].format(
                city=city,
                description=description,
                temperature=f'{temperature:.1f}°C',
                humidity=humidity,
                wind_speed=wind_speed,
            )

        if self.command.verb == 'tell':
            if not self.command.query:
                return responses['error_handler']['query_404']
            if self._description_matches(self.command.query, description):
                return f'Yes, {city} is {self.command.query}.'
            return f'No, {city} is not {self.command.query}.'

        return responses['wrong_input']['missing_object']

    @staticmethod
    def _description_matches(query: str, description: str) -> bool:
        synonyms = {
            'sunny': 'sun',
            'sun': 'sun',
            'rainy': 'rain',
            'rain': 'rain',
            'cloudy': 'cloud',
            'clouds': 'cloud',
            'windy': 'wind',
            'snowy': 'snow',
            'foggy': 'fog',
            'clear': 'clear',
            'fog': 'fog',
        }
        query_norm = synonyms.get(query.lower(), query.lower())
        description_tokens = description.lower().replace('-', ' ').split()
        description_norm_tokens = {synonyms.get(token, token) for token in description_tokens}
        return query_norm in description_norm_tokens or query.lower() in description.lower()
